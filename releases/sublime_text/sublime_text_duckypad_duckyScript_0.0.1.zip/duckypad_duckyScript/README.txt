Latest instructions:

https://github.com/duckyPad/duckyScript-Syntax-Highlighter/blob/master/README.md